class EmployeeManager {
    constructor() {
      this.currentEditId = null;
      this.initEmployees();
      this.initForm();
      this.initImageUpload();
      this.loadEmployees();
    }
  
    initEmployees() {
      if (!localStorage.getItem('employees')) {
        localStorage.setItem('employees', JSON.stringify([]));
      }
    }
  
    initForm() {
      const form = document.getElementById('employeeForm');
      if (form) {
        form.addEventListener('submit', (e) => {
          e.preventDefault();
          if (this.currentEditId) {
            this.updateEmployee();
          } else {
            this.addEmployee();
          }
        });
  
        // Add cancel button functionality
        const cancelBtn = document.createElement('button');
        cancelBtn.textContent = 'Cancel';
        cancelBtn.className = 'btn btn-secondary';
        cancelBtn.style.marginLeft = '10px';
        cancelBtn.style.display = 'none';
        cancelBtn.addEventListener('click', (e) => {
          e.preventDefault();
          this.cancelEdit();
        });
        form.querySelector('button[type="submit"]').after(cancelBtn);
        this.cancelBtn = cancelBtn;
      }
    }
  
    initImageUpload() {
      const fileInput = document.getElementById('profileImage');
      const fileLabel = document.getElementById('fileLabel');
      const imagePreview = document.getElementById('imagePreview');
  
      fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          fileLabel.textContent = file.name;
          
          const reader = new FileReader();
          reader.onload = (event) => {
            imagePreview.innerHTML = `<img src="${event.target.result}" alt="Preview">`;
          };
          reader.readAsDataURL(file);
        }
      });
    }
  
    addEmployee() {
      const fileInput = document.getElementById('profileImage');
      let imageUrl = '';
      
      if (fileInput.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
          imageUrl = e.target.result;
          this.saveEmployee(imageUrl, true);
        };
        reader.readAsDataURL(fileInput.files[0]);
      } else {
        this.saveEmployee(imageUrl, true);
      }
    }
  
    saveEmployee(imageUrl, isNew = false) {
      const employee = {
        id: isNew ? Date.now() : this.currentEditId,
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        email: document.getElementById('email').value,
        department: document.getElementById('department').value,
        salary: document.getElementById('salary').value,
        image: imageUrl || this.currentImage,
        joinDate: document.getElementById('joinDate')?.value || new Date().toISOString().split('T')[0]
      };
  
      let employees = JSON.parse(localStorage.getItem('employees'));
      
      if (isNew) {
        employees.push(employee);
      } else {
        const index = employees.findIndex(e => e.id === this.currentEditId);
        if (index !== -1) {
          // Preserve image if not changed
          if (!imageUrl && this.currentImage) {
            employee.image = this.currentImage;
          }
          employees[index] = employee;
        }
      }
      
      localStorage.setItem('employees', JSON.stringify(employees));
      this.loadEmployees();
      this.resetForm();
    }
  
    updateEmployee() {
      const fileInput = document.getElementById('profileImage');
      
      if (fileInput.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
          this.saveEmployee(e.target.result);
        };
        reader.readAsDataURL(fileInput.files[0]);
      } else {
        this.saveEmployee('');
      }
    }
  
    loadEmployees() {
      const employees = JSON.parse(localStorage.getItem('employees'));
      const table = document.getElementById('employeeTable');
      
      table.innerHTML = employees.map(emp => `
        <tr data-id="${emp.id}">
          <td>
            ${emp.image ? 
              `<img src="${emp.image}" class="employee-image">` : 
              '<div class="employee-image placeholder">👤</div>'}
          </td>
          <td>${emp.firstName} ${emp.lastName}</td>
          <td>${emp.email}</td>
          <td>${emp.department || 'N/A'}</td>
          <td>${emp.salary ? '$' + emp.salary : 'N/A'}</td>
          <td>${emp.joinDate || 'N/A'}</td>
          <td>
            <button class="btn-edit" data-id="${emp.id}">Edit</button>
            <button class="btn-delete" data-id="${emp.id}">Delete</button>
          </td>
        </tr>
      `).join('') || '<tr><td colspan="7">No employees found</td></tr>';
  
      this.initDeleteButtons();
      this.initEditButtons();
    }
  
    initDeleteButtons() {
      document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = parseInt(e.target.dataset.id);
          this.deleteEmployee(id);
        });
      });
    }
  
    initEditButtons() {
      document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = parseInt(e.target.dataset.id);
          this.editEmployee(id);
        });
      });
    }
  
    editEmployee(id) {
      const employees = JSON.parse(localStorage.getItem('employees'));
      const employee = employees.find(e => e.id === id);
      
      if (employee) {
        this.currentEditId = id;
        this.currentImage = employee.image;
        
        document.getElementById('firstName').value = employee.firstName;
        document.getElementById('lastName').value = employee.lastName;
        document.getElementById('email').value = employee.email;
        document.getElementById('department').value = employee.department || '';
        document.getElementById('salary').value = employee.salary || '';
        
        const imagePreview = document.getElementById('imagePreview');
        if (employee.image) {
          imagePreview.innerHTML = `<img src="${employee.image}" alt="Preview">`;
        } else {
          imagePreview.innerHTML = '';
        }
        
        document.getElementById('fileLabel').textContent = employee.image ? 'Image selected' : 'Choose Profile Image';
        
        // Change submit button text
        document.querySelector('#employeeForm button[type="submit"]').textContent = 'Update Employee';
        
        // Show cancel button
        this.cancelBtn.style.display = 'inline-block';
        
        // Scroll to form
        document.getElementById('employeeForm').scrollIntoView({ behavior: 'smooth' });
      }
    }
  
    cancelEdit() {
      this.currentEditId = null;
      this.resetForm();
    }
  
    resetForm() {
      document.getElementById('employeeForm').reset();
      document.getElementById('imagePreview').innerHTML = '';
      document.getElementById('fileLabel').textContent = 'Choose Profile Image';
      document.querySelector('#employeeForm button[type="submit"]').textContent = 'Add Employee';
      this.cancelBtn.style.display = 'none';
      this.currentImage = null;
    }
  
    deleteEmployee(id) {
      if (confirm('Are you sure you want to delete this employee?')) {
        let employees = JSON.parse(localStorage.getItem('employees'));
        employees = employees.filter(emp => emp.id !== id);
        localStorage.setItem('employees', JSON.stringify(employees));
        this.loadEmployees();
      }
    }
  }
  
  document.addEventListener('DOMContentLoaded', () => new EmployeeManager());