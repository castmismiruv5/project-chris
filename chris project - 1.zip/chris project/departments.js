document.addEventListener('DOMContentLoaded', () => {
    // Initialize departments if not exists
    if (!localStorage.getItem('departments')) {
      localStorage.setItem('departments', JSON.stringify([]));
    }
  
    // Load employees for manager dropdown
    const employees = JSON.parse(localStorage.getItem('employees')) || [];
    const managerSelect = document.getElementById('deptManager');
    
    managerSelect.innerHTML = `
      <option value="">Select Manager</option>
      ${employees.map(emp => `
        <option value="${emp.id}">
          ${emp.firstName} ${emp.lastName}
        </option>
      `).join('')}
    `;
  
    // Form submission
    document.getElementById('departmentForm').addEventListener('submit', (e) => {
      e.preventDefault();
      
      const department = {
        id: Date.now(),
        name: document.getElementById('deptName').value,
        manager: document.getElementById('deptManager').value
      };
  
      const departments = JSON.parse(localStorage.getItem('departments'));
      departments.push(department);
      localStorage.setItem('departments', JSON.stringify(departments));
      
      loadDepartments();
      e.target.reset();
    });
  
    // Load departments
    function loadDepartments() {
      const departments = JSON.parse(localStorage.getItem('departments')) || [];
      const employees = JSON.parse(localStorage.getItem('employees')) || [];
      const table = document.getElementById('departmentTable');
      
      table.innerHTML = departments.map(dept => {
        const manager = employees.find(e => e.id == dept.manager) || {};
        const employeeCount = employees.filter(e => e.department === dept.name).length;
        
        return `
          <tr data-id="${dept.id}">
            <td>${dept.name}</td>
            <td>${manager.firstName || 'None'} ${manager.lastName || ''}</td>
            <td>${employeeCount}</td>
            <td>
              <button class="btn-edit" data-id="${dept.id}">Edit</button>
              <button class="btn-delete" data-id="${dept.id}">Delete</button>
            </td>
          </tr>
        `;
      }).join('') || '<tr><td colspan="4">No departments found</td></tr>';
  
      // Add delete functionality
      document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = parseInt(e.target.dataset.id);
          deleteDepartment(id);
        });
      });
    }
  
    // Delete department
    function deleteDepartment(id) {
      if (confirm('Are you sure you want to delete this department?')) {
        let departments = JSON.parse(localStorage.getItem('departments'));
        departments = departments.filter(d => d.id !== id);
        localStorage.setItem('departments', JSON.stringify(departments));
        loadDepartments();
      }
    }
  
    // Initial load
    loadDepartments();
  });