// Initialize auth system
function initAuth() {
    // Check login status
    if (localStorage.getItem('isLoggedIn')) {
      const currentPage = window.location.pathname.split('/').pop();
      if (currentPage === 'index.html') {
        window.location.href = 'dashboard.html';
      }
    } else {
      const protectedPages = ['dashboard.html', 'employees.html', 'payroll.html', 'departments.html'];
      const currentPage = window.location.pathname.split('/').pop();
      
      if (protectedPages.includes(currentPage)) {
        window.location.href = 'index.html';
      }
    }
  
    // Login form handler
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorElement = document.getElementById('loginError');
        
        // Check credentials
        if ((username === 'admin' && password === 'admin123') || 
            (username === 'hr' && password === 'hr123')) {
          localStorage.setItem('isLoggedIn', 'true');
          localStorage.setItem('username', username);
          localStorage.setItem('role', username === 'admin' ? 'admin' : 'hr');
          window.location.href = 'dashboard.html';
        } else {
          errorElement.textContent = 'Invalid username or password';
          errorElement.style.color = 'var(--danger)';
        }
      });
    }
  
    // Logout handler
    const logoutBtn = document.querySelector('.logout-link');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', function(e) {
        e.preventDefault();
        localStorage.clear();
        window.location.href = 'index.html';
      });
    }
  
    // Set active nav item
    const currentPage = window.location.pathname.split('/').pop();
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === currentPage) {
        link.classList.add('active');
      }
    });
  
    // Display username
    const usernameElement = document.querySelector('.user-info span');
    if (usernameElement) {
      usernameElement.textContent = localStorage.getItem('username');
    }
  }
  
  // Initialize when DOM loads
  document.addEventListener('DOMContentLoaded', initAuth);