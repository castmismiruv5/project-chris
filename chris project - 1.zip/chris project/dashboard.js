class Dashboard {
    constructor() {
      this.initStats();
    }
  
    initStats() {
      const employees = JSON.parse(localStorage.getItem('employees')) || [];
      const payroll = JSON.parse(localStorage.getItem('payroll')) || [];
      const departments = JSON.parse(localStorage.getItem('departments')) || [];
      
      // Update stats
      document.getElementById('totalEmployees').textContent = employees.length;
      document.getElementById('totalPayroll').textContent = 
        '$' + payroll.reduce((sum, p) => sum + (parseFloat(p.basicSalary) || 0), 0).toLocaleString();
      document.getElementById('totalDepartments').textContent = departments.length;
      
      // Show recent employees
      this.showRecentEmployees(employees.slice(-5));
    }
  
    showRecentEmployees(employees) {
      const table = document.getElementById('recentEmployees');
      
      table.innerHTML = `
        <thead>
          <tr>
            <th>Name</th>
            <th>Department</th>
            <th>Join Date</th>
            <th>Salary</th>
          </tr>
        </thead>
        <tbody>
          ${employees.map(emp => `
            <tr>
              <td>${emp.firstName} ${emp.lastName}</td>
              <td>${emp.department || 'N/A'}</td>
              <td>${emp.joinDate || 'N/A'}</td>
              <td>$${emp.salary || '0'}</td>
            </tr>
          `).join('')}
        </tbody>
      `;
    }
  }
  
  // Initialize when DOM loads
  document.addEventListener('DOMContentLoaded', () => new Dashboard());