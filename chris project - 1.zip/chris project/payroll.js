document.addEventListener('DOMContentLoaded', () => {
    // Initialize payroll data if not exists
    if (!localStorage.getItem('payroll')) {
      localStorage.setItem('payroll', JSON.stringify([]));
    }
  
    // Load employees for dropdown
    const employees = JSON.parse(localStorage.getItem('employees')) || [];
    const employeeSelect = document.getElementById('employeeId');
    
    employeeSelect.innerHTML = `
      <option value="">Select Employee</option>
      ${employees.map(emp => `
        <option value="${emp.id}">
          ${emp.firstName} ${emp.lastName} (${emp.department || 'No Dept'})
        </option>
      `).join('')}
    `;
  
    // Calculate total salary automatically
    document.getElementById('basicSalary').addEventListener('input', calculateTotal);
    document.getElementById('bonus').addEventListener('input', calculateTotal);
    document.getElementById('deductions').addEventListener('input', calculateTotal);
  
    function calculateTotal() {
      const basic = parseFloat(document.getElementById('basicSalary').value) || 0;
      const bonus = parseFloat(document.getElementById('bonus').value) || 0;
      const deductions = parseFloat(document.getElementById('deductions').value) || 0;
      const total = basic + bonus - deductions;
      document.getElementById('totalSalary').value = total.toFixed(2);
    }
  
    // Form submission
    document.getElementById('payrollForm').addEventListener('submit', (e) => {
      e.preventDefault();
      
      const payrollData = {
        id: Date.now(),
        employeeId: parseInt(document.getElementById('employeeId').value),
        monthYear: document.getElementById('monthYear').value,
        basicSalary: parseFloat(document.getElementById('basicSalary').value),
        bonus: parseFloat(document.getElementById('bonus').value) || 0,
        deductions: parseFloat(document.getElementById('deductions').value) || 0,
        status: 'Pending',
        processedDate: new Date().toISOString()
      };
  
      // Calculate total
      payrollData.totalSalary = payrollData.basicSalary + payrollData.bonus - payrollData.deductions;
  
      const payrollRecords = JSON.parse(localStorage.getItem('payroll'));
      payrollRecords.push(payrollData);
      localStorage.setItem('payroll', JSON.stringify(payrollRecords));
      
      loadPayrollRecords();
      e.target.reset();
      document.getElementById('totalSalary').value = '';
    });
  
    // Load payroll records
    function loadPayrollRecords() {
      const payrollRecords = JSON.parse(localStorage.getItem('payroll')) || [];
      const employees = JSON.parse(localStorage.getItem('employees')) || [];
      const table = document.getElementById('payrollTable');
      
      table.innerHTML = payrollRecords.map(payroll => {
        const employee = employees.find(e => e.id == payroll.employeeId) || {};
        
        return `
          <tr data-id="${payroll.id}">
            <td>${employee.firstName || 'Unknown'} ${employee.lastName || ''}</td>
            <td>${payroll.monthYear}</td>
            <td>$${payroll.basicSalary.toFixed(2)}</td>
            <td>$${payroll.bonus.toFixed(2)}</td>
            <td>$${payroll.deductions.toFixed(2)}</td>
            <td>$${payroll.totalSalary.toFixed(2)}</td>
            <td class="status-${payroll.status.toLowerCase()}">${payroll.status}</td>
            <td>
              <button class="btn-delete" data-id="${payroll.id}">Delete</button>
            </td>
          </tr>
        `;
      }).join('') || '<tr><td colspan="8">No payroll records found</td></tr>';
  
      // Add delete functionality
      document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = parseInt(e.target.dataset.id);
          deletePayrollRecord(id);
        });
      });
    }
  
    // Delete payroll record
    function deletePayrollRecord(id) {
      if (confirm('Are you sure you want to delete this payroll record?')) {
        let payrollRecords = JSON.parse(localStorage.getItem('payroll'));
        payrollRecords = payrollRecords.filter(p => p.id !== id);
        localStorage.setItem('payroll', JSON.stringify(payrollRecords));
        loadPayrollRecords();
      }
    }
  
    // Initial load
    loadPayrollRecords();
  });